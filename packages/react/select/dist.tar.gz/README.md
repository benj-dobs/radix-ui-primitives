# `react-select`

## Installation

```sh
$ yarn add @radix-ui/react-select
# or
$ npm install @radix-ui/react-select
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/select).
